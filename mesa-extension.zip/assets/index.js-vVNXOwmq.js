(function(){function c(){const t=document.body.cloneNode(!0);["script","style","noscript","iframe","svg"].forEach(n=>{t.querySelectorAll(n).forEach(r=>r.remove())});let e=t.innerText;return e=e.replace(/\s+/g," ").trim(),e}chrome.runtime.onMessage.addListener((t,o,e)=>{if(t.action==="GET_PAGE_CONTENT"){const n=c();e({content:n,type:"web"})}});
})()
